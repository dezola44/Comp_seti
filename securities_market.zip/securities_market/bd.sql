-- CREATE DATABASE securities_market;

-- Таблица: Классы бумаг
CREATE TABLE security_classes (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    risks TEXT,
    profitability NUMERIC(5,2) -- доходность в %
);

-- Таблица: Эмитенты
CREATE TABLE issuers (
    id SERIAL PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    industry VARCHAR(100),
    phone VARCHAR(20),
    website VARCHAR(150)
);

-- Таблица: Сделки
CREATE TABLE transactions (
    id SERIAL PRIMARY KEY,
    security_class_id INT NOT NULL REFERENCES security_classes(id) ON DELETE CASCADE,
    issuer_id INT NOT NULL REFERENCES issuers(id) ON DELETE CASCADE,
    volume NUMERIC(15,2) NOT NULL,
    transaction_date DATE NOT NULL
);

-- Пример заполнения таблиц

INSERT INTO security_classes (name, risks, profitability)
VALUES
('Акции', 'Высокие рыночные риски', 12.50),
('Облигации', 'Низкие кредитные риски', 6.30),
('ETF', 'Средние рыночные риски', 8.10);

INSERT INTO issuers (name, industry, phone, website)
VALUES
('Газпром', 'Энергетика', '+7-495-719-30-01', 'https://www.gazprom.ru'),
('Сбербанк', 'Финансы', '+7-495-500-55-50', 'https://www.sberbank.ru'),
('Лукойл', 'Нефтегазовая отрасль', '+7-495-627-44-44', 'https://www.lukoil.ru');

INSERT INTO transactions (security_class_id, issuer_id, volume, transaction_date)
VALUES
(1, 1, 1500000.00, '2026-05-10'),
(2, 2, 500000.00, '2026-05-12'),
(3, 3, 750000.00, '2026-05-15');
