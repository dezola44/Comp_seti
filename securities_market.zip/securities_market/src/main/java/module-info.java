module ru.volkov.securities_market {
    requires javafx.controls;
    requires javafx.fxml;
    requires jakarta.persistence;
    requires org.hibernate.orm.core;
    requires java.naming;

    exports ru.volkov.securities_market;
    exports ru.volkov.securities_market.controller.issuer;
    exports ru.volkov.securities_market.controller.securityclass;
    exports ru.volkov.securities_market.controller.transaction;
    exports ru.volkov.securities_market.model;

    opens ru.volkov.securities_market to javafx.fxml;
    opens ru.volkov.securities_market.controller.issuer to javafx.fxml;
    opens ru.volkov.securities_market.controller.securityclass to javafx.fxml;
    opens ru.volkov.securities_market.controller.transaction to javafx.fxml;
    opens ru.volkov.securities_market.model to org.hibernate.orm.core, javafx.base;
}