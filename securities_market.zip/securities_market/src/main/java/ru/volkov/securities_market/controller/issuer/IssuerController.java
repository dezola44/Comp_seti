package ru.volkov.securities_market.controller.issuer;

import ru.volkov.securities_market.Main;
import ru.volkov.securities_market.model.Issuer;
import ru.volkov.securities_market.service.IssuerService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

public class IssuerController {

    private List<Issuer> issuers;
    private ObservableList<Issuer> issuersObservable;

    @FXML
    private TableView<Issuer> issuersTable;

    @FXML
    private TableColumn<Issuer, String> nameColumn;
    @FXML
    private TableColumn<Issuer, String> industryColumn;
    @FXML
    private TableColumn<Issuer, String> phoneColumn;
    @FXML
    private TableColumn<Issuer, String> websiteColumn;


    @FXML
    void addIssuer(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(Main.class.getResource("add-edit-issuer-dialog.fxml"));
            Stage dialogStage = new Stage();
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(Main.primaryStage);
            dialogStage.setMinWidth(550);
            dialogStage.setScene(new Scene(loader.load()));
            dialogStage.setTitle("Добавить эмитента");
            AddEditIssuerDialog controller = loader.getController();
            controller.setAddDialogStage(dialogStage);
            dialogStage.showAndWait();
            updateList();
        } catch (IOException e) {
            System.out.println("Ошибка открытия окна: " + e.getMessage());
        }
    }

    @FXML
    void editIssuer(ActionEvent event) {
        Issuer currentItem = issuersTable.getSelectionModel().getSelectedItem();
        int currentItemId = issuersTable.getSelectionModel().getSelectedIndex();
        if (currentItemId != -1) {
            try {
                FXMLLoader loader = new FXMLLoader(Main.class.getResource("add-edit-issuer-dialog.fxml"));
                Stage dialogStage = new Stage();
                dialogStage.initModality(Modality.WINDOW_MODAL);
                dialogStage.initOwner(Main.primaryStage);
                dialogStage.setMinWidth(550);
                dialogStage.setScene(new Scene(loader.load()));
                dialogStage.setTitle("Редактировать эмитента");
                AddEditIssuerDialog controller = loader.getController();
                controller.setEditDialogStage(dialogStage, currentItem);
                dialogStage.showAndWait();
                updateList();
            } catch (IOException e) {
                System.out.println("Ошибка открытия окна: " + e.getMessage());
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Предупреждение");
            alert.setContentText("Выберите запись в таблице для редактирования");
            alert.showAndWait();
        }
    }

    @FXML
    void deleteIssuer(ActionEvent event) {
        Issuer currentItem = issuersTable.getSelectionModel().getSelectedItem();
        int currentItemId = issuersTable.getSelectionModel().getSelectedIndex();
        if (currentItemId != -1) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Подтверждение удаления");
            alert.setHeaderText("Удаление записи");
            alert.setContentText("Вы действительно хотите удалить эмитента \"" +
                    currentItem.getName() + "\"?");

            Optional<ButtonType> result = alert.showAndWait();

            if (result.isPresent() && result.get() == ButtonType.OK) {
                new IssuerService().delete(currentItem);
                issuersTable.getItems().remove(currentItemId);
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Предупреждение");
            alert.setContentText("Выберите запись в таблице для удаления");
            alert.showAndWait();
        }
    }

    @FXML
    void updateIssuers(ActionEvent event) {
        updateList();
    }

    @FXML
    void powerOff(ActionEvent event) {
        Main.primaryStage.close();
    }

    public void updateList() {
        issuers = new IssuerService().findAll();
        issuersObservable = FXCollections.observableArrayList(issuers);
        issuersTable.setItems(issuersObservable);
    }

    public void initialize() {
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        industryColumn.setCellValueFactory(new PropertyValueFactory<>("industry"));
        phoneColumn.setCellValueFactory(new PropertyValueFactory<>("phone"));
        websiteColumn.setCellValueFactory(new PropertyValueFactory<>("website"));

        updateList();
    }

    public void onSecurityClassesButtonClick(ActionEvent actionEvent) {
        Main.primaryStage.setScene(Main.securityClasses);
    }

    public void onTransactionsButtonClick(ActionEvent actionEvent) {
        Main.primaryStage.setScene(Main.transactions);
    }
}