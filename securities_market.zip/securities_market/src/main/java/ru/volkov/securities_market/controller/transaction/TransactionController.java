package ru.volkov.securities_market.controller.transaction;

import ru.volkov.securities_market.Main;
import ru.volkov.securities_market.model.*;
import ru.volkov.securities_market.service.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Optional;

public class TransactionController {

    private List<Transaction> transactions;
    private ObservableList<Transaction> transactionsObservable;

    @FXML
    private TableView<Transaction> transactionsTable;

    @FXML
    private TableColumn<Transaction, String> issuerNameColumn;
    @FXML
    private TableColumn<Transaction, String> securityClassNameColumn;
    @FXML
    private TableColumn<Transaction, Number> volumeColumn;
    @FXML
    private TableColumn<Transaction, Date> transactionDateColumn;

    @FXML
    void onIssuersButtonClick(ActionEvent event) throws IOException {
        Main.primaryStage.setScene(Main.issuers);
    }

    @FXML
    void onSecurityClassesButtonClick(ActionEvent event) throws IOException {
        Main.primaryStage.setScene(Main.securityClasses);
    }

    @FXML
    void addTransaction(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(Main.class.getResource("add-edit-transaction-dialog.fxml"));
            Stage dialogStage = new Stage();
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(Main.primaryStage);
            dialogStage.setMinWidth(550);
            dialogStage.setScene(new Scene(loader.load()));
            dialogStage.setTitle("Добавить транзакцию");
            AddEditTransactionDialog controller = loader.getController();
            controller.setAddDialogStage(dialogStage);
            dialogStage.showAndWait();
            updateList();
        } catch (IOException e) {
            System.out.println("Ошибка открытия окна: " + e.getMessage());
        }
    }

    @FXML
    void editTransaction(ActionEvent event) {
        Transaction currentItem = transactionsTable.getSelectionModel().getSelectedItem();
        int currentItemId = transactionsTable.getSelectionModel().getSelectedIndex();
        if (currentItemId != -1) {
            try {
                FXMLLoader loader = new FXMLLoader(Main.class.getResource("add-edit-transaction-dialog.fxml"));
                Stage dialogStage = new Stage();
                dialogStage.initModality(Modality.WINDOW_MODAL);
                dialogStage.initOwner(Main.primaryStage);
                dialogStage.setMinWidth(550);
                dialogStage.setScene(new Scene(loader.load()));
                dialogStage.setTitle("Редактировать транзакцию");
                AddEditTransactionDialog controller = loader.getController();
                controller.setEditDialogStage(dialogStage, currentItem);
                dialogStage.showAndWait();
                updateList();
            } catch (IOException e) {
                System.out.println("Ошибка открытия окна: " + e.getMessage());
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Предупреждение");
            alert.setContentText("Выберите запись в таблице для редактирования");
            alert.showAndWait();
        }
    }

    @FXML
    void deleteTransaction(ActionEvent event) {
        Transaction currentItem = transactionsTable.getSelectionModel().getSelectedItem();
        int currentItemId = transactionsTable.getSelectionModel().getSelectedIndex();
        if (currentItemId != -1) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Подтверждение удаления");
            alert.setHeaderText("Удаление записи");
            alert.setContentText("Вы действительно хотите удалить транзакцию для \"" +
                    (currentItem.getIssuer() != null ? currentItem.getIssuer().getName() : "") +
                    "\" от " + currentItem.getTransactionDate() + "?");

            Optional<ButtonType> result = alert.showAndWait();

            if (result.isPresent() && result.get() == ButtonType.OK) {
                new TransactionService().delete(currentItem);
                transactionsTable.getItems().remove(currentItemId);
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Предупреждение");
            alert.setContentText("Выберите запись в таблице для удаления");
            alert.showAndWait();
        }
    }

    @FXML
    void updateTransactions(ActionEvent event) {
        updateList();
    }

    @FXML
    void powerOff(ActionEvent event) {
        Main.primaryStage.close();
    }

    public void updateList() {
        transactions = new TransactionService().findAll();
        transactionsObservable = FXCollections.observableArrayList(transactions);
        transactionsTable.setItems(transactionsObservable);
    }

    public void initialize() {
        volumeColumn.setCellValueFactory(new PropertyValueFactory<>("volume"));
        transactionDateColumn.setCellValueFactory(new PropertyValueFactory<>("transactionDate"));

        issuerNameColumn.setCellValueFactory(cellData -> {
            if (cellData.getValue().getIssuer() != null) {
                return new javafx.beans.property.SimpleStringProperty(
                        cellData.getValue().getIssuer().getName()
                );
            }
            return new javafx.beans.property.SimpleStringProperty("");
        });

        securityClassNameColumn.setCellValueFactory(cellData -> {
            if (cellData.getValue().getSecurityClass() != null) {
                return new javafx.beans.property.SimpleStringProperty(
                        cellData.getValue().getSecurityClass().getName()
                );
            }
            return new javafx.beans.property.SimpleStringProperty("");
        });

        updateList();
    }
}