package ru.volkov.securities_market.repository;

import ru.volkov.securities_market.model.Issuer;

public class IssuerDao extends BaseDao<Issuer>{
    public IssuerDao(){
        super(Issuer.class);
    }
}
