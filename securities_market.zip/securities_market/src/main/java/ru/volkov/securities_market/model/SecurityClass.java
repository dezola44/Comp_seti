package ru.volkov.securities_market.model;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "security_classes")
public class SecurityClass {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "name", nullable = false, length = 100)
    private String name;

    @Column(name = "risks")
    private String risks;

    @Column(name = "profitability", precision = 5, scale = 2)
    private BigDecimal profitability;

    // Геттеры и сеттеры
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name != null && !name.trim().isEmpty()) {
            this.name = name;
        } else {
            throw new IllegalArgumentException("Название класса бумаг не может быть пустым!");
        }
    }

    public String getRisks() {
        return risks;
    }

    public void setRisks(String risks) {
        this.risks = risks;
    }

    public BigDecimal getProfitability() {
        return profitability;
    }

    public void setProfitability(String profitability) {
        if (profitability != null && !profitability.isEmpty()) {
            try {
                BigDecimal value = new BigDecimal(profitability);
                if (value.compareTo(BigDecimal.ZERO) >= 0) {
                    this.profitability = value;
                } else {
                    throw new IllegalArgumentException("Доходность должна быть больше или равна 0!");
                }
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("Доходность должна быть числом!");
            }
        } else {
            this.profitability = null;
        }
    }

    public void setProfitability(BigDecimal profitability) {
        if (profitability != null && profitability.compareTo(BigDecimal.ZERO) >= 0) {
            this.profitability = profitability;
        } else if (profitability == null) {
            this.profitability = null;
        } else {
            throw new IllegalArgumentException("Доходность должна быть больше или равна 0!");
        }
    }

    @Override
    public String toString() {
        return name;
    }
}