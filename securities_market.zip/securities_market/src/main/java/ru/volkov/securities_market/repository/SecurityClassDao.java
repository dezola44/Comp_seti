package ru.volkov.securities_market.repository;

import ru.volkov.securities_market.model.SecurityClass;

public class SecurityClassDao extends BaseDao<SecurityClass> {
    public SecurityClassDao() {
        super(SecurityClass.class);
    }
}