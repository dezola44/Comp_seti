package ru.volkov.securities_market.repository;

import ru.volkov.securities_market.model.Transaction;

public class TransactionDao extends BaseDao<Transaction> {
    public TransactionDao(){
        super(Transaction.class);
    }
}
