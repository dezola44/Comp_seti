package ru.volkov.securities_market.controller.issuer;

import ru.volkov.securities_market.model.Issuer;
import ru.volkov.securities_market.service.IssuerService;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class AddEditIssuerDialog {

    @FXML
    private TextField nameField;
    @FXML
    private TextField industryField;
    @FXML
    private TextField phoneField;
    @FXML
    private TextField websiteField;
    @FXML
    private Button okButton;
    @FXML
    private Label errorLabel;

    private Stage dialogStage;
    private Issuer issuer;

    void add() {
        try {
            validateFields();

            Issuer newIssuer = new Issuer();
            newIssuer.setName(nameField.getText());
            newIssuer.setIndustry(industryField.getText());
            newIssuer.setPhone(phoneField.getText());
            newIssuer.setWebsite(websiteField.getText());

            new IssuerService().save(newIssuer);
            dialogStage.close();
        } catch (IllegalArgumentException e) {
            errorLabel.setText(e.getMessage());
        } catch (Exception e) {
            errorLabel.setText("Ошибка при сохранении: " + e.getMessage());
        }
    }

    public void setAddDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;

        nameField.clear();
        industryField.clear();
        phoneField.clear();
        websiteField.clear();

        okButton.setOnAction((event) -> add());
    }

    void edit() {
        try {
            validateFields();

            issuer.setName(nameField.getText());
            issuer.setIndustry(industryField.getText());
            issuer.setPhone(phoneField.getText());
            issuer.setWebsite(websiteField.getText());

            new IssuerService().update(issuer);
            dialogStage.close();
        } catch (IllegalArgumentException e) {
            errorLabel.setText(e.getMessage());
        } catch (Exception e) {
            errorLabel.setText("Ошибка при обновлении: " + e.getMessage());
        }
    }

    public void setEditDialogStage(Stage dialogStage, Issuer issuer) {
        this.dialogStage = dialogStage;
        this.issuer = issuer;

        // Установка текущих значений
        nameField.setText(issuer.getName());
        industryField.setText(issuer.getIndustry());
        phoneField.setText(issuer.getPhone());
        websiteField.setText(issuer.getWebsite());

        okButton.setOnAction((event) -> edit());
    }


    private void validateFields() {
        if (nameField.getText() == null || nameField.getText().trim().isEmpty()) {
            throw new IllegalArgumentException("Введите название эмитента!");
        }

        if (websiteField.getText() != null && !websiteField.getText().trim().isEmpty()) {
            String website = websiteField.getText().trim();
            if (!website.startsWith("http://") && !website.startsWith("https://")) {
                throw new IllegalArgumentException("Веб-сайт должен начинаться с http:// или https://");
            }
        }
    }
}