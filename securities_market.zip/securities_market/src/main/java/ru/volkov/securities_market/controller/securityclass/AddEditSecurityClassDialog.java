package ru.volkov.securities_market.controller.securityclass;

import ru.volkov.securities_market.model.SecurityClass;
import ru.volkov.securities_market.service.SecurityClassService;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.math.BigDecimal;

public class AddEditSecurityClassDialog {

    @FXML
    private TextField nameField;
    @FXML
    private TextArea risksArea;
    @FXML
    private TextField profitabilityField;
    @FXML
    private Button okButton;
    @FXML
    private Label errorLabel;

    private Stage dialogStage;
    private SecurityClass securityClass;

    void add() {
        try {
            validateFields();

            SecurityClass newSecurityClass = new SecurityClass();
            newSecurityClass.setName(nameField.getText());
            newSecurityClass.setRisks(risksArea.getText());
            newSecurityClass.setProfitability(profitabilityField.getText());

            new SecurityClassService().save(newSecurityClass);
            dialogStage.close();
        } catch (IllegalArgumentException e) {
            errorLabel.setText(e.getMessage());
        } catch (Exception e) {
            errorLabel.setText("Ошибка при сохранении: " + e.getMessage());
        }
    }

    public void setAddDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;

        nameField.clear();
        risksArea.clear();
        profitabilityField.clear();

        okButton.setOnAction((event) -> add());
    }

    void edit() {
        try {
            validateFields();

            securityClass.setName(nameField.getText());
            securityClass.setRisks(risksArea.getText());
            securityClass.setProfitability(profitabilityField.getText());

            new SecurityClassService().update(securityClass);
            dialogStage.close();
        } catch (IllegalArgumentException e) {
            errorLabel.setText(e.getMessage());
        } catch (Exception e) {
            errorLabel.setText("Ошибка при обновлении: " + e.getMessage());
        }
    }

    public void setEditDialogStage(Stage dialogStage, SecurityClass securityClass) {
        this.dialogStage = dialogStage;
        this.securityClass = securityClass;

        nameField.setText(securityClass.getName());
        risksArea.setText(securityClass.getRisks());
        profitabilityField.setText(securityClass.getProfitability() != null ?
                securityClass.getProfitability().toString() : "");

        okButton.setOnAction((event) -> edit());
    }


    private void validateFields() {
        if (nameField.getText() == null || nameField.getText().trim().isEmpty()) {
            throw new IllegalArgumentException("Введите название класса бумаг!");
        }

        // Проверка доходности
        if (profitabilityField.getText() != null && !profitabilityField.getText().trim().isEmpty()) {
            try {
                BigDecimal profitability = new BigDecimal(profitabilityField.getText());
                if (profitability.compareTo(BigDecimal.ZERO) < 0) {
                    throw new IllegalArgumentException("Доходность должна быть больше или равна 0!");
                }
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("Доходность должна быть числом!");
            }
        }
    }
}