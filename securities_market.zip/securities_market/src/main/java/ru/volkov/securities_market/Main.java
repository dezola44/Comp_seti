package ru.volkov.securities_market;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class Main extends Application {
    public static Stage primaryStage;
    public static Scene securityClasses;
    public static Scene issuers;
    public static Scene transactions;

    @Override
    public void start(Stage stage) throws IOException {
        primaryStage = stage;
        securityClasses = createScene("security-classes-view.fxml");
        issuers = createScene("issuers-view.fxml");
        transactions = createScene("transactions-view.fxml");
        primaryStage.setMinWidth(1200);
        primaryStage.setMinHeight(675);
        primaryStage.setTitle("Рынок ценных бумаг. Особенности, проблемы и перспективы");
        primaryStage.setScene(transactions);
        primaryStage.show();
    }

    private Scene createScene(String name) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource(name));
        return new Scene(fxmlLoader.load());
    }

    public static void main(String[] args) {
        launch();
    }
}
