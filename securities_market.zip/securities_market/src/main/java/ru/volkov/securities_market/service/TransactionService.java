package ru.volkov.securities_market.service;

import ru.volkov.securities_market.repository.TransactionDao;
import ru.volkov.securities_market.model.Transaction;

import java.math.BigDecimal;
import java.util.List;

public class TransactionService {
    private TransactionDao transactionDao = new TransactionDao();

    public TransactionService() {
    }

    public List<Transaction> findAll() {
        return transactionDao.findAll();
    }

    public Transaction findOne(final long id) {
        return transactionDao.findOne(id);
    }

    public void save(final Transaction entity) {
        if (entity == null)
            return;

        // Проверка объема перед сохранением
        if (entity.getVolume() == null || entity.getVolume().compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Объем транзакции должен быть больше 0!");
        }

        transactionDao.save(entity);
    }

    public void update(final Transaction entity) {
        if (entity == null)
            return;

        // Проверка объема перед обновлением
        if (entity.getVolume() == null || entity.getVolume().compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Объем транзакции должен быть больше 0!");
        }

        transactionDao.update(entity);
    }

    public void delete(final Transaction entity) {
        if (entity == null)
            return;
        transactionDao.delete(entity);
    }

    public void deleteById(final Long id) {
        if (id == null)
            return;
        transactionDao.deleteById(id);
    }
}