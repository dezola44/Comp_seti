package ru.volkov.securities_market.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "transactions")
public class Transaction {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "security_class_id", nullable = false)
    private SecurityClass securityClass;

    @ManyToOne
    @JoinColumn(name = "issuer_id", nullable = false)
    private Issuer issuer;

    @Column(name = "volume", nullable = false, precision = 15, scale = 2)
    private BigDecimal volume;

    @Column(name = "transaction_date", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date transactionDate;

    // Геттеры и сеттеры
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public SecurityClass getSecurityClass() {
        return securityClass;
    }

    public void setSecurityClass(SecurityClass securityClass) {
        if (securityClass != null) {
            this.securityClass = securityClass;
        } else {
            throw new IllegalArgumentException("Класс бумаг не может быть пустым!");
        }
    }

    public Issuer getIssuer() {
        return issuer;
    }

    public void setIssuer(Issuer issuer) {
        if (issuer != null) {
            this.issuer = issuer;
        } else {
            throw new IllegalArgumentException("Эмитент не может быть пустым!");
        }
    }

    public BigDecimal getVolume() {
        return volume;
    }

    public void setVolume(String volume) {
        if (volume != null && !volume.isEmpty()) {
            try {
                BigDecimal value = new BigDecimal(volume);
                if (value.compareTo(BigDecimal.ZERO) > 0) {
                    this.volume = value;
                } else {
                    throw new IllegalArgumentException("Объем транзакции должен быть больше 0!");
                }
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("Объем транзакции должен быть числом!");
            }
        } else {
            throw new IllegalArgumentException("Объем транзакции не может быть пустым!");
        }
    }

    public void setVolume(BigDecimal volume) {
        if (volume != null && volume.compareTo(BigDecimal.ZERO) > 0) {
            this.volume = volume;
        } else {
            throw new IllegalArgumentException("Объем транзакции должен быть больше 0!");
        }
    }

    public Date getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(Date transactionDate) {
        if (transactionDate != null) {
            this.transactionDate = transactionDate;
        } else {
            throw new IllegalArgumentException("Дата транзакции не может быть пустой!");
        }
    }

    @Override
    public String toString() {
        return "Transaction{" +
                "id=" + id +
                ", securityClass=" + (securityClass != null ? securityClass.getName() : null) +
                ", issuer=" + (issuer != null ? issuer.getName() : null) +
                ", volume=" + volume +
                ", transactionDate=" + transactionDate +
                '}';
    }
}