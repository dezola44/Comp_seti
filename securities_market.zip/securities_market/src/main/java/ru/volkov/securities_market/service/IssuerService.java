package ru.volkov.securities_market.service;

import ru.volkov.securities_market.repository.IssuerDao;
import ru.volkov.securities_market.model.Issuer;

import java.util.List;

public class IssuerService {
    private IssuerDao issuerDao = new IssuerDao();

    public IssuerService() {
    }

    public List<Issuer> findAll() {
        return issuerDao.findAll();
    }

    public Issuer findOne(final long id) {
        return issuerDao.findOne(id);
    }

    public void save(final Issuer entity) {
        if (entity == null)
            return;

        // Проверка названия перед сохранением
        if (entity.getName() == null || entity.getName().trim().isEmpty()) {
            throw new IllegalArgumentException("Название эмитента не может быть пустым!");
        }

        issuerDao.save(entity);
    }

    public void update(final Issuer entity) {
        if (entity == null)
            return;

        // Проверка названия перед обновлением
        if (entity.getName() == null || entity.getName().trim().isEmpty()) {
            throw new IllegalArgumentException("Название эмитента не может быть пустым!");
        }

        issuerDao.update(entity);
    }

    public void delete(final Issuer entity) {
        if (entity == null)
            return;
        issuerDao.delete(entity);
    }

    public void deleteById(final Long id) {
        if (id == null)
            return;
        issuerDao.deleteById(id);
    }
}