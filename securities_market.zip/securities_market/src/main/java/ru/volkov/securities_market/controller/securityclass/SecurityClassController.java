package ru.volkov.securities_market.controller.securityclass;

import ru.volkov.securities_market.Main;
import ru.volkov.securities_market.model.SecurityClass;
import ru.volkov.securities_market.service.SecurityClassService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

public class SecurityClassController {

    private List<SecurityClass> securityClasses;
    private ObservableList<SecurityClass> securityClassesObservable;

    @FXML
    private TableView<SecurityClass> securityClassesTable;

    @FXML
    private TableColumn<SecurityClass, String> nameColumn;
    @FXML
    private TableColumn<SecurityClass, String> risksColumn;
    @FXML
    private TableColumn<SecurityClass, Number> profitabilityColumn;

    @FXML
    void addSecurityClass(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(Main.class.getResource("add-edit-security-class-dialog.fxml"));
            Stage dialogStage = new Stage();
            dialogStage.initModality(Modality.WINDOW_MODAL);
            dialogStage.initOwner(Main.primaryStage);
            dialogStage.setMinWidth(550);
            dialogStage.setScene(new Scene(loader.load()));
            dialogStage.setTitle("Добавить класс бумаг");
            AddEditSecurityClassDialog controller = loader.getController();
            controller.setAddDialogStage(dialogStage);
            dialogStage.showAndWait();
            updateList();
        } catch (IOException e) {
            System.out.println("Ошибка открытия окна: " + e.getMessage());
        }
    }

    @FXML
    void editSecurityClass(ActionEvent event) {
        SecurityClass currentItem = securityClassesTable.getSelectionModel().getSelectedItem();
        int currentItemId = securityClassesTable.getSelectionModel().getSelectedIndex();
        if (currentItemId != -1) {
            try {
                FXMLLoader loader = new FXMLLoader(Main.class.getResource("add-edit-security-class-dialog.fxml"));
                Stage dialogStage = new Stage();
                dialogStage.initModality(Modality.WINDOW_MODAL);
                dialogStage.initOwner(Main.primaryStage);
                dialogStage.setMinWidth(550);
                dialogStage.setScene(new Scene(loader.load()));
                dialogStage.setTitle("Редактировать класс бумаг");
                AddEditSecurityClassDialog controller = loader.getController();
                controller.setEditDialogStage(dialogStage, currentItem);
                dialogStage.showAndWait();
                updateList();
            } catch (IOException e) {
                System.out.println("Ошибка открытия окна: " + e.getMessage());
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Предупреждение");
            alert.setContentText("Выберите запись в таблице для редактирования");
            alert.showAndWait();
        }
    }

    @FXML
    void deleteSecurityClass(ActionEvent event) {
        SecurityClass currentItem = securityClassesTable.getSelectionModel().getSelectedItem();
        int currentItemId = securityClassesTable.getSelectionModel().getSelectedIndex();
        if (currentItemId != -1) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Подтверждение удаления");
            alert.setHeaderText("Удаление записи");
            alert.setContentText("Вы действительно хотите удалить класс бумаг \"" +
                    currentItem.getName() + "\"?");

            Optional<ButtonType> result = alert.showAndWait();

            if (result.isPresent() && result.get() == ButtonType.OK) {
                new SecurityClassService().delete(currentItem);
                securityClassesTable.getItems().remove(currentItemId);
            }
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Предупреждение");
            alert.setContentText("Выберите запись в таблице для удаления");
            alert.showAndWait();
        }
    }

    @FXML
    void updateSecurityClasses(ActionEvent event) {
        updateList();
    }

    @FXML
    void powerOff(ActionEvent event) {
        Main.primaryStage.close();
    }

    public void updateList() {
        securityClasses = new SecurityClassService().findAll();
        securityClassesObservable = FXCollections.observableArrayList(securityClasses);
        securityClassesTable.setItems(securityClassesObservable);
    }

    public void initialize() {
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        risksColumn.setCellValueFactory(new PropertyValueFactory<>("risks"));
        profitabilityColumn.setCellValueFactory(new PropertyValueFactory<>("profitability"));

        updateList();
    }

    public void onTransactionsButtonClick(ActionEvent actionEvent) {
        Main.primaryStage.setScene(Main.transactions);
    }

    public void onIssuersButtonClick(ActionEvent actionEvent) {
        Main.primaryStage.setScene(Main.issuers);
    }
}