package ru.volkov.securities_market.controller.transaction;

import ru.volkov.securities_market.model.*;
import ru.volkov.securities_market.service.*;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;

public class AddEditTransactionDialog {

    @FXML
    private ComboBox<Issuer> issuerCombo;
    @FXML
    private ComboBox<SecurityClass> securityClassCombo;
    @FXML
    private TextField volumeField;
    @FXML
    private DatePicker transactionDatePicker;
    @FXML
    private Button okButton;
    @FXML
    private Label errorLabel;

    private Stage dialogStage;
    private Transaction transaction;

    void add() {
        try {
            validateFields();

            Transaction newTransaction = new Transaction();
            newTransaction.setIssuer(issuerCombo.getValue());
            newTransaction.setSecurityClass(securityClassCombo.getValue());
            newTransaction.setVolume(volumeField.getText());
            newTransaction.setTransactionDate(Date.from(transactionDatePicker.getValue()
                    .atStartOfDay(ZoneId.systemDefault()).toInstant()));

            new TransactionService().save(newTransaction);
            dialogStage.close();
        } catch (IllegalArgumentException e) {
            errorLabel.setText(e.getMessage());
        } catch (Exception e) {
            errorLabel.setText("Ошибка при сохранении: " + e.getMessage());
        }
    }

    public void setAddDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;

        List<Issuer> issuers = new IssuerService().findAll();
        issuerCombo.getItems().addAll(FXCollections.observableList(issuers));

        List<SecurityClass> securityClasses = new SecurityClassService().findAll();
        securityClassCombo.getItems().addAll(FXCollections.observableList(securityClasses));

        if (!issuerCombo.getItems().isEmpty()) {
            issuerCombo.setValue(issuers.get(0));
        }
        if (!securityClassCombo.getItems().isEmpty()) {
            securityClassCombo.setValue(securityClasses.get(0));
        }
        transactionDatePicker.setValue(LocalDate.now());

        okButton.setOnAction((event) -> add());
    }

    void edit() {
        try {
            validateFields();

            transaction.setIssuer(issuerCombo.getValue());
            transaction.setSecurityClass(securityClassCombo.getValue());
            transaction.setVolume(volumeField.getText());
            transaction.setTransactionDate(Date.from(transactionDatePicker.getValue()
                    .atStartOfDay(ZoneId.systemDefault()).toInstant()));

            new TransactionService().update(transaction);
            dialogStage.close();
        } catch (IllegalArgumentException e) {
            errorLabel.setText(e.getMessage());
        } catch (Exception e) {
            errorLabel.setText("Ошибка при обновлении: " + e.getMessage());
        }
    }

    public void setEditDialogStage(Stage dialogStage, Transaction transaction) {
        this.dialogStage = dialogStage;
        this.transaction = transaction;

        List<Issuer> issuers = new IssuerService().findAll();
        issuerCombo.getItems().addAll(FXCollections.observableList(issuers));

        List<SecurityClass> securityClasses = new SecurityClassService().findAll();
        securityClassCombo.getItems().addAll(FXCollections.observableList(securityClasses));

        issuerCombo.setValue(transaction.getIssuer());
        securityClassCombo.setValue(transaction.getSecurityClass());
        volumeField.setText(transaction.getVolume().toString());
        transactionDatePicker.setValue(Instant.ofEpochMilli(transaction.getTransactionDate().getTime())
                .atZone(ZoneId.systemDefault()).toLocalDate());


        okButton.setOnAction((event) -> edit());
    }


    private void validateFields() {
        if (issuerCombo.getValue() == null) {
            throw new IllegalArgumentException("Выберите эмитента!");
        }
        if (securityClassCombo.getValue() == null) {
            throw new IllegalArgumentException("Выберите класс бумаг!");
        }
        if (volumeField.getText() == null || volumeField.getText().trim().isEmpty()) {
            throw new IllegalArgumentException("Введите объем транзакции!");
        }
        if (transactionDatePicker.getValue() == null) {
            throw new IllegalArgumentException("Выберите дату транзакции!");
        }

        // Проверка объема
        try {
            BigDecimal volume = new BigDecimal(volumeField.getText());
            if (volume.compareTo(BigDecimal.ZERO) <= 0) {
                throw new IllegalArgumentException("Объем транзакции должен быть больше 0!");
            }
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Объем транзакции должен быть числом!");
        }
    }
}