package ru.volkov.securities_market.service;

import ru.volkov.securities_market.repository.SecurityClassDao;
import ru.volkov.securities_market.model.SecurityClass;

import java.util.List;

public class SecurityClassService {
    private SecurityClassDao securityClassDao = new SecurityClassDao();

    public SecurityClassService() {
    }

    public List<SecurityClass> findAll() {
        return securityClassDao.findAll();
    }

    public SecurityClass findOne(final long id) {
        return securityClassDao.findOne(id);
    }

    public void save(final SecurityClass entity) {
        if (entity == null)
            return;

        // Проверка названия перед сохранением
        if (entity.getName() == null || entity.getName().trim().isEmpty()) {
            throw new IllegalArgumentException("Название класса бумаг не может быть пустым!");
        }

        securityClassDao.save(entity);
    }

    public void update(final SecurityClass entity) {
        if (entity == null)
            return;

        // Проверка названия перед обновлением
        if (entity.getName() == null || entity.getName().trim().isEmpty()) {
            throw new IllegalArgumentException("Название класса бумаг не может быть пустым!");
        }

        securityClassDao.update(entity);
    }

    public void delete(final SecurityClass entity) {
        if (entity == null)
            return;
        securityClassDao.delete(entity);
    }

    public void deleteById(final Long id) {
        if (id == null)
            return;
        securityClassDao.deleteById(id);
    }
}